<?php
session_start();

// Page Title
$pageTitle = 'Cars';

// Includes
include 'connect.php'; // Ensure this uses MySQLi for connection
include 'Includes/functions/functions.php'; 
include 'Includes/templates/header.php';

// Check If user is already logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {
?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Cars</h1>
        </div>

        <!-- ADD NEW CAR SUBMITTED -->
        <?php
        // ADD NEW CAR SUBMITTED
if (isset($_POST['add_car_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_brand = test_input($_POST['car_brand']);
    $car_model = test_input($_POST['car_model']);
    $car_description = test_input($_POST['car_description']);
    $car_image = $_FILES['car_image'];

    // Image validation
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 2 * 1024 * 1024; // 2MB

    if ($car_image['error'] == UPLOAD_ERR_OK) {
        // Check the file type and size
        if (in_array($car_image['type'], $allowed_types) && $car_image['size'] <= $max_size) {
            // Rename the file to avoid conflicts
            $car_image_name = rand(0, 100000) . '_' . basename($car_image['name']);
            $upload_path = "Uploads/images/" . $car_image_name;

            // Move the uploaded file
            if (move_uploaded_file($car_image['tmp_name'], $upload_path)) {
                $stmt = $con->prepare("INSERT INTO cars (brand_id, model, description, car_image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isss", $car_brand, $car_model, $car_description, $car_image_name);

                if ($stmt->execute()) {
                    echo "<div class='alert alert-success'>New Car has been added successfully</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error occurred: " . $con->error . "</div>";
                }

                $stmt->close();
            } else {
                echo "<div class='alert alert-danger'>Failed to upload the image. Please try again.</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>Invalid file type or size. Please upload a JPEG, PNG, or GIF image under 2MB.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Error occurred during file upload: " . $car_image['error'] . "</div>";
    }
}

        // EDIT CAR SUBMITTED
        if (isset($_POST['edit_car_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $car_id = $_POST['car_id'];
            $car_brand = test_input($_POST['car_brand']);
            $car_model = test_input($_POST['car_model']);
            $car_description = test_input($_POST['car_description']);
            $car_image = $_FILES['car_image']['name'] ? rand(0, 100000) . '_' . $_FILES['car_image']['name'] : null;

            if ($car_image) {
                // Move the new uploaded image and update the database with the new image.
                move_uploaded_file($_FILES['car_image']['tmp_name'], "Uploads/images/" . $car_image);
                $stmt = $con->prepare("UPDATE cars SET brand_id = ?, model = ?, description = ?, car_image = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param('ssssi', $car_brand, $car_model, $car_description, $car_image, $car_id);
                    $stmt->execute();
                    echo "<div class='alert alert-success'>Car has been updated successfully</div>";
                    $stmt->close();
                }
            } else {
                // Update only the other details if no new image is uploaded.
                $stmt = $con->prepare("UPDATE cars SET brand_id = ?, model = ?, description = ? WHERE id = ?");
                if ($stmt) {
                    $stmt->bind_param('sssi', $car_brand, $car_model, $car_description, $car_id);
                    $stmt->execute();
                    echo "<div class='alert alert-success'>Car has been updated successfully</div>";
                    $stmt->close();
                }
            }
        }

        // DELETE CAR SUBMITTED
        if (isset($_POST['delete_car_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            // Debugging
            error_log("Delete car ID: " . $_POST['car_id']);
            error_log("Delete car image: " . $_POST['car_image']);
            
            $car_id = $_POST['car_id'];
            $car_image = $_POST['car_image'];

            // Delete the car record from the database
            $stmt = $con->prepare("DELETE FROM cars WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param('i', $car_id);
                if ($stmt->execute()) {
                    // If car image exists, delete the image from the server
                    if (!empty($car_image) && file_exists("Uploads/images/" . $car_image)) {
                        unlink("Uploads/images/" . $car_image);
                    }
                    echo "<div class='alert alert-success'>Car has been deleted successfully</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error occurred while deleting the car: " . $stmt->error . "</div>";
                }
                $stmt->close();
            } else {
                echo "<div class='alert alert-danger'>Error preparing statement: " . $con->error . "</div>";
            }
        }
        ?>

        <!-- Cars Table -->
        <?php
        $result = $con->query("SELECT * FROM cars");
        $rows_cars = $result->fetch_all(MYSQLI_ASSOC);

        $result = $con->query("SELECT * FROM car_brands");
        $rows_brands = $result->fetch_all(MYSQLI_ASSOC);
        ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Cars</h6>
            </div>
            <div class="card-body">

                <!-- ADD NEW CAR BUTTON -->
                <button class="btn btn-success btn-sm" style="margin-bottom: 10px;" type="button" data-toggle="modal" data-target="#add_new_car" data-placement="top">
                    <i class="fa fa-plus"></i> 
                    Add New Car
                </button>

                <!-- Cars Table -->
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Car ID</th>
                                <th>Brand</th>
                                <th>Model</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
    <?php
    foreach ($rows_cars as $car) {
        echo "<tr>";
        echo "<td>" . $car['id'] . "</td>";
        echo "<td>" . $car['brand_id'] . "</td>";
        echo "<td>" . $car['model'] . "</td>";
        echo "<td>" . $car['description'] . "</td>";
        echo "<td><img src='Uploads/images/" . $car['car_image'] . "' style='max-width: 100px; max-height: 100px;' /></td>";
        echo "<td>";
        
        // Updated manage buttons with button group
        echo '<div class="btn-group" role="group" aria-label="Manage Brands">
                <button class="btn btn-warning btn-sm rounded-0" type="button" data-toggle="modal" data-target="#edit_car_' . $car['id'] . '" data-placement="top">
                    <i class="fa fa-edit"></i> 
                </button>
                <button class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="modal" data-target="#delete_car_' . $car['id'] . '" data-placement="top">
                    <i class="fa fa-trash"></i> 
                </button>
              </div>';
        
        echo "</td>";
        echo "</tr>";

        // Existing Edit Car Modal for each car
        echo '
        <div class="modal fade" id="edit_car_' . $car['id'] . '" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Car</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="cars.php" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="car_brand">Car Brand</label>
                                <select name="car_brand" class="custom-select">';
                                    foreach ($rows_brands as $brand) {
                                        echo "<option value='" . $brand['brand_id'] . "' " . ($car['brand_id'] == $brand['brand_id'] ? "selected" : "") . ">" . $brand['brand_name'] . "</option>";
                                    }
                echo               '</select>
                            </div>
                            <div class="form-group">
                                <label for="car_model">Car Model</label>
                                <input type="text" class="form-control" name="car_model" value="' . $car['model'] . '">
                            </div>
                            <div class="form-group">
                                <label for="car_description">Car Description</label>
                                <textarea class="form-control" name="car_description">' . $car['description'] . '</textarea>
                            </div>
                            <div class="form-group">
                                <label for="car_image">Car Image</label>
                                <input type="file" class="form-control-file" name="car_image">
                            </div>
                            <input type="hidden" name="car_id" value="' . $car['id'] . '">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="edit_car_sbmt">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>';

        // Existing Delete Car Modal for each car
        echo '
        <div class="modal fade" id="delete_car_' . $car['id'] . '" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Delete Car</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="cars.php" method="POST">
                        <div class="modal-body">
                            <p>Are you sure you want to delete this car?</p>
                            <input type="hidden" name="car_id" value="' . $car['id'] . '">
                            <input type="hidden" name="car_image" value="' . $car['car_image'] . '">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger" name="delete_car_sbmt">Delete</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>';
    }
    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ADD NEW CAR MODAL -->
        <div class="modal fade" id="add_new_car" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add New Car</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="cars.php" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="car_brand">Car Brand</label>
                                <select name="car_brand" class="custom-select">
                                    <?php
                                    foreach ($rows_brands as $brand) {
                                        echo "<option value='" . $brand['brand_id'] . "'>" . $brand['brand_name'] . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="car_model">Car Model</label>
                                <input type="text" class="form-control" name="car_model">
                            </div>
                            <div class="form-group">
                                <label for="car_description">Car Description</label>
                                <textarea class="form-control" name="car_description"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="car_image">Car Image</label>
                                <input type="file" class="form-control-file" name="car_image" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" name="add_car_sbmt">Add Car</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <!-- End of Main Content -->
<?php
} else {
    header('Location: login.php'); // Redirect if not logged in
}
include 'Includes/templates/footer.php'; 
?>
