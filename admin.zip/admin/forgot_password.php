<?php
session_start();
$pageTitle = 'Forgot Password';
include 'connect.php';
include 'Includes/functions/functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = test_input($_POST['username']);
    $newPassword = test_input($_POST['new_password']);
    
    // Check if the username matches and update the password in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Assuming you have a hashed password in the database, hash the new password before saving it
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        // Update password in database
        $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $updateStmt->bind_param("ss", $hashedPassword, $username);
        
        if ($updateStmt->execute()) {
            echo '<div class="alert alert-success">Password updated successfully! You can now log in with your new password.</div>';
        } else {
            echo '<div class="alert alert-danger">Failed to update password!</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Username does not exist!</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Forgot Password</title>
    <!-- Include your styles and scripts here -->
</head>
<body>
    <div class="container">
        <form method="POST" action="forgot_password.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required />

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required />

            <button type="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
