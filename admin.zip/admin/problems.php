<?php
session_start();

// Page Title
$pageTitle = 'Report Problems';

// Includes
include 'connect.php'; // Ensure your connection uses MySQLi
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';

// Check if the user is logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {
    // Begin Page Content
    ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Reported Problems</h1>
        </div>

        <!-- Reported Problems Table -->
        <?php
        // Fetch reported problems from the database
        $stmt = $con->prepare("SELECT * FROM problems ORDER BY created_at DESC");
        
        // Check if the statement was prepared successfully
        if ($stmt) {
            $stmt->execute();
            $result = $stmt->get_result(); // Retrieve a result set
            
            // Begin card layout
            ?>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Reported Problems</h6>
                </div>
                <div class="card-body">
                    <!-- Reported Problems Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Problem Type</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Time Reported</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Display each reported problem
                                if ($result->num_rows > 0) {
                                    while ($problem = $result->fetch_assoc()) {
                                        echo "<tr>";
                                            echo "<td>{$problem['id']}</td>";
                                            echo "<td>{$problem['name']}</td>";
                                            echo "<td>{$problem['email']}</td>";
                                            echo "<td>{$problem['problem_type']}</td>";
                                            echo "<td>{$problem['message']}</td>";
                                            echo "<td>{$problem['created_at']}</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='6' class='text-center'>No reported problems found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php
            // Close the statement
            $stmt->close();
        } else {
            echo "<div class='alert alert-danger'>Error fetching reported problems: " . $con->error . "</div>";
        }
        ?>
    </div>

<?php 
    // Include Footer
    include 'Includes/templates/footer.php';
} else {
    // Redirect to login if not logged in
    header('Location: index.php');
    exit();
}
?>
