		<!-- Footer Bottom Section -->
		<footer class="footer_section">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="copyright">
							varni © 
							<script type="text/javascript"> 
								document.write(new Date().getFullYear())
							</script>
							All rights reserved 
						</div>
					</div>
					<div class="col-md-6">
						<ul class="footer_link">
							
							
							
					</div>
				</div>
			</div>
		</footer>

		<!-- INCLUDE JS SCRIPTS -->
		<script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
		<script src="Design/js/jquery.min.js"></script>
		<script src="Design/js/bootstrap-js/bootstrap.min.js"></script>
		<script src="Design/js/bootstrap-js/bootstrap.bundle.min.js"></script>
		<script src="Design/js/main-script.js"></script>

	</body>

	<!-- END BODY TAG -->

</html>

<!-- END HTML TAG -->