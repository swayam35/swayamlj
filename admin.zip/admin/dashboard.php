<?php 
	session_start();

	//Check If user is already logged in
	if(isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental']))
	{
        //Page Title
        $pageTitle = 'Dashboard';

        //Includes
        include 'connect.php';
        include 'Includes/functions/functions.php'; 
        include 'Includes/templates/header.php';

?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                
            </div>

            <!-- Cancel Reservation Button Submitted -->
            <?php
                if (isset($_POST['cancel_reservation_sbmt']) && $_SERVER['REQUEST_METHOD'] === 'POST')
                {
                    $reservation_id = $_POST['reservation_id'];
                    $reservation_cancellation_reason = test_input($_POST['reservation_cancellation_reason']);
                    try
                    {
                        $stmt = $con->prepare("UPDATE reservations set canceled = 1, cancellation_reason = ? where reservation_id = ?");
                        $stmt->execute(array($reservation_cancellation_reason, $reservation_id));
                        echo "<div class = 'alert alert-success'>";
                            echo 'Reservation has been canceled succssefully!';
                        echo "</div>";
                    }
                    catch(Exception $e)
                    {
                        echo "<div class = 'alert alert-danger'>";
                            echo 'Error occurred: ' .$e->getMessage();
                        echo "</div>";
                    }
                }
                // Assume this is executed on an admin page where they can see pending reservations
if (isset($_POST['approve'])) {
  $reservation_id = $_POST['reservation_id']; // Get the reservation ID to approve
  $stmt_approve = $con->prepare("UPDATE reservations SET status = 'approved' WHERE id = ?");
  $stmt_approve->execute(array($reservation_id));

  // Fetch client email to notify them
  $stmt_fetch_client = $con->prepare("SELECT client_email, full_name FROM clients WHERE id = (SELECT client_id FROM reservations WHERE id = ?)");
  $stmt_fetch_client->execute(array($reservation_id));
  $client = $stmt_fetch_client->fetch();

  // Notify user about approval
  $subject = "Reservation Approved";
  $message = "Dear {$client['full_name']},\n\nYour reservation has been approved! Thank you for choosing us.\n\nBest Regards,\nCar Rental Team";
  mail($client['client_email'], $subject, $message, $headers);
  
  echo "<div class='alert alert-success'>Reservation approved and email sent to {$client['client_email']}.</div>";
}

            ?>

            <!-- Content Row -->
            <div class="row">
  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-primary shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Clients</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("client_id","clients")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-user fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-success shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Car Brands</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("brand_id","car_brands")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-car fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-info shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Cars</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("id","cars")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-car-side fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total Reservations</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("reservation_id","reservations")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Contacts</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("id","contacts")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-address-book fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-xl-2 col-md-6 mb-2">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="row no-gutters align-items-center">
          <div class="col mr-2">
            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Subscribers</div>
            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo countItems("id","subscribers")?></div>
          </div>
          <div class="col-auto">
            <i class="fas fa-users fa-2x text-gray-300"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

            <!-- Reservations Tables -->
            <div class="card shadow mb-2">
                <div class="card-header tab" style="padding: 0px !important;background: #36b9cc!important">
                    <button class="tablinks active" onclick="openTab(event, 'Upcoming')">
                        Upcoming Reservations
                    </button>
                    <button class="tablinks" onclick="openTab(event, 'All')">
                        All Reservations
                    </button>
                    <button class="tablinks" onclick="openTab(event, 'Canceled')">
                        Canceled Reservations
                    </button>
                </div>
               
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered tabcontent" id="Upcoming" style="display:table" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Pickup Date</th>
                        <th>Pickup Location</th>
                        <th>Return Date</th>
                        <th>Return Location</th>
                        <th>Selected Car</th>
                        <th>Client</th>
                        <th>Manage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                                        // Upcoming Reservations
                    $stmt = $con->prepare("SELECT r.*, c.car_name FROM reservations r JOIN cars c ON r.car_id = c.id WHERE pickup_date >= ? AND canceled = 0 ORDER BY pickup_date");
                    $current_date = date('Y-m-d H:i:s');
                    $stmt->bind_param("s", $current_date);  // Bind the current date as a string
                    $stmt->execute();
                    $result = $stmt->get_result();  // Get the result set
                    $rows = $result->fetch_all(MYSQLI_ASSOC);  // Fetch all rows as an associative array
                    $count = $result->num_rows; 




                    if ($count == 0) {
                        echo "<tr><td colspan='7' style='text-align:center;'>List of your upcoming reservations will be presented here</td></tr>";
                    } else {
                        foreach ($rows as $row) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['pickup_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['pickup_location']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_location']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['car_name']) . "</td>";
                            echo "<td><a href='#'>" . htmlspecialchars($row['client_id']) . "</a></td>";
                            echo "<td>";

                            $cancel_data = "cancel_reservation_" . $row["reservation_id"];
                            $approve_data = "approve_reservation_" . $row["reservation_id"]; // Approval modal ID
                            ?>
                            <ul class="list-inline m-0">
                                <!-- CANCEL BUTTON -->
                                <li class="list-inline-item" data-toggle="tooltip" title="Cancel Reservation">
                                    <button class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="modal" data-target="#<?php echo $cancel_data; ?>" data-placement="top">
                                        <i class="fas fa-calendar-times"></i>
                                    </button>
                                    <!-- CANCEL MODAL -->
                                    <div class="modal fade" id="<?php echo $cancel_data; ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo $cancel_data; ?>" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form action="dashboard.php" method="POST">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Cancel Reservation</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to cancel this reservation?</p>
                                                        <input type="hidden" value="<?php echo $row['reservation_id']; ?>" name="reservation_id">
                                                        <div class="form-group">
                                                            <label>Tell Us Why?</label>
                                                            <textarea class="form-control" name="reservation_cancellation_reason"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                                        <button type="submit" name="cancel_reservation_sbmt" class="btn btn-danger">Yes, Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </li>

                                <!-- APPROVE BUTTON -->
                                <li class="list-inline-item" data-toggle="tooltip" title="Approve Reservation">
                                    <button class="btn btn-success btn-sm rounded-0" type="button" data-toggle="modal" data-target="#<?php echo $approve_data; ?>" data-placement="top">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <!-- APPROVE MODAL -->
                                    <div class="modal fade" id="<?php echo $approve_data; ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo $approve_data; ?>" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form action="dashboard.php" method="POST">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Approve Reservation</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Are you sure you want to approve this reservation?</p>
                                                        <input type="hidden" value="<?php echo $row['reservation_id']; ?>" name="reservation_id">
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                                                        <button type="submit" name="approve_reservation_sbmt" class="btn btn-success">Yes, Approve</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <?php
                            echo "</td></tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>

            <table class="table table-bordered tabcontent" id="All" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Pickup Date</th>
                        <th>Return Date</th>
                        <th>Selected Car</th>
                        <th>Client</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $con->prepare("SELECT * FROM reservations WHERE canceled = 0 ORDER BY pickup_date");
                    $stmt->execute();
                    $result = $stmt->get_result(); // Get the result set
                    $rows = $result->fetch_all(MYSQLI_ASSOC); // Fetch all rows as an associative array
                    $count = $result->num_rows; // Get the number of rows

                    if ($count == 0) {
                        echo "<tr><td colspan='4' style='text-align:center;'>List of your all reservations will be presented here</td></tr>";
                    } else {
                        foreach ($rows as $row) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['pickup_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['car_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['client_id']) . "</td>";
                            echo "</tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>

            <table class="table table-bordered tabcontent" id="Canceled" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Pickup Date</th>
                        <th>Return Date</th>
                        <th>Selected Car</th>
                        <th>Client</th>
                        <th>Cancellation Reason</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $stmt = $con->prepare("SELECT * FROM reservations WHERE canceled = 1");
$stmt->execute();
$result = $stmt->get_result(); // Get the result set
$rows = $result->fetch_all(MYSQLI_ASSOC); // Fetch all rows as an associative array
$count = $result->num_rows; // Get the number of rows

                    if ($count == 0) {
                        echo "<tr><td colspan='5' style='text-align:center;'>List of your canceled reservations will be presented here</td></tr>";
                    } else {
                        foreach ($rows as $row) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['pickup_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['return_date']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['car_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['client_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['cancellation_reason']) . "</td>";
                            echo "</tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
// Include Footer
include 'Includes/templates/footer.php';
} else {
    header('Location: index.php');
    exit();
}
?>
