<?php
session_start();

// Page Title
$pageTitle = 'Newsletter Subscribers';

// Includes
include 'connect.php'; // Ensure this uses MySQLi
include 'Includes/functions/functions.php';
include 'Includes/templates/header.php';

// Check if the user is logged in
if (isset($_SESSION['username_yahya_car_rental']) && isset($_SESSION['password_yahya_car_rental'])) {
?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Newsletter Subscribers</h1>
           
        </div>

        <!-- Subscribers Table -->
        <?php
        // Fetch subscribers from the database
        try {
            // Prepare the SQL statement
            $stmt = $con->prepare("SELECT * FROM subscribers ORDER BY id ");
            $stmt->execute(); // Execute the statement
            $result = $stmt->get_result(); // Get the result set
            $subscribers = $result->fetch_all(MYSQLI_ASSOC); // Fetch all results as an associative array
        } catch (Exception $e) {
            $_SESSION['error'] = "Error fetching subscribers: " . $e->getMessage();
            $subscribers = [];
        }
        ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Subscribers</h6>
            </div>
            <div class="card-body">
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php elseif (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">ID#</th>
                                <th scope="col">Email</th>
                                <th scope="col">Date Subscribed</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($subscribers): ?>
                                <?php foreach ($subscribers as $subscriber): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($subscriber['id']); ?></td>
                                        <td><?php echo htmlspecialchars($subscriber['email']); ?></td>
                                        <td><?php echo htmlspecialchars($subscriber['created_at']); ?></td>
                                        <td>
                                            <a href="?delete=<?php echo htmlspecialchars($subscriber['id']); ?>" 
                                               onclick="return confirm('Are you sure you want to delete this subscriber?');">
                                               Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4">No subscribers found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php 
    // Include Footer
    include 'Includes/templates/footer.php';
} else {
    // Redirect to login if not logged in
    header('Location: index.php');
    exit();
}
?>
